<label class="{{ ($required ?? false) ? 'label label-required ' : 'label ' }}" for="{{ $name }}">
    {{ $label }}
</label>